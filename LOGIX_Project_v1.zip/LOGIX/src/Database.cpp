#include "Database.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QStandardPaths>
#include <QDir>

static QSqlDatabase db;

QSqlDatabase Database::connection() { return db; }

bool Database::initialize(QString *error) {
    if (QSqlDatabase::contains("logix_connection"))
        db = QSqlDatabase::database("logix_connection");
    else {
        db = QSqlDatabase::addDatabase("QSQLITE", "logix_connection");
        const QString folder = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
        QDir().mkpath(folder);
        db.setDatabaseName(folder + "/logix.db");
    }
    if (!db.open()) {
        if (error) *error = db.lastError().text();
        return false;
    }
    QSqlQuery q(db);
    const QStringList statements = {
        "PRAGMA foreign_keys = ON",
        "CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE NOT NULL, name TEXT NOT NULL)",
        "CREATE TABLE IF NOT EXISTS subjects(id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE NOT NULL, name TEXT NOT NULL)",
        "CREATE TABLE IF NOT EXISTS enrollments(id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE, subject_id INTEGER NOT NULL REFERENCES subjects(id) ON DELETE CASCADE, UNIQUE(student_id, subject_id))",
        "CREATE TABLE IF NOT EXISTS exam_schedule(subject_id INTEGER PRIMARY KEY REFERENCES subjects(id) ON DELETE CASCADE, slot INTEGER NOT NULL)"
    };
    for (const auto &sql : statements) {
        if (!q.exec(sql)) {
            if (error) *error = q.lastError().text();
            return false;
        }
    }
    return true;
}
