#include "MainWindow.h"
#include <QApplication>
#include <QFont>

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    QApplication::setApplicationName("LOGIX");
    QApplication::setOrganizationName("LOGIX");
    app.setFont(QFont("Montserrat", 10));
    MainWindow window;
    window.show();
    return app.exec();
}
