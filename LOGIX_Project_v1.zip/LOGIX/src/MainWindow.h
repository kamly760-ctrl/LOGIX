#pragma once
#include <QMainWindow>
#include <QTableWidget>
#include <QLabel>
#include <QComboBox>
#include <QStringList>

class QTabWidget;

class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent=nullptr);
private:
    bool arabic=false;
    QTabWidget *tabs=nullptr;
    QTableWidget *studentsTable=nullptr, *subjectsTable=nullptr, *enrollTable=nullptr, *scheduleTable=nullptr;
    QLabel *statusLabel=nullptr;
    QWidget *makeDataPage(QTableWidget **table, const QStringList &headers);
    void refreshAll();
    void addStudent();
    void addSubject();
    void addEnrollment();
    void importCsv(bool students);
    void generateSchedule();
    void exportSchedule();
    void toggleLanguage();
    void applyLanguage();
    void setupStyle();
};
