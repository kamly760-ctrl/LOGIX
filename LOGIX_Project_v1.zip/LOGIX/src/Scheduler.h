#pragma once
#include <QMap>
#include <QString>

struct ScheduleResult {
    QMap<QString, int> examSlots;
    int slotCount = 0;
    bool valid = true;
    QString error;
};

class Scheduler {
public:
    // Welsh-Powell graph coloring: each subject is a vertex; shared students create edges.
    static ScheduleResult build();
    static bool validate(const QMap<QString, int> &examSlots, QString *error = nullptr);
};
