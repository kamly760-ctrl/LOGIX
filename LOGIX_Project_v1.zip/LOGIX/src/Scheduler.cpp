#include "Scheduler.h"
#include "Database.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QVector>
#include <QSet>
#include <algorithm>

ScheduleResult Scheduler::build() {
    ScheduleResult result;
    auto db = Database::connection();
    QSqlQuery subjects(db);
    if (!subjects.exec("SELECT id, code FROM subjects ORDER BY code")) {
        result.valid = false; result.error = subjects.lastError().text(); return result;
    }
    QVector<int> ids;
    QStringList codes;
    while (subjects.next()) { ids << subjects.value(0).toInt(); codes << subjects.value(1).toString(); }
    const int n = ids.size();
    if (n == 0) { result.valid = false; result.error = "Add subjects before scheduling."; return result; }

    QVector<QSet<int>> graph(n);
    QSqlQuery enroll(db);
    if (!enroll.exec("SELECT e.student_id, e.subject_id FROM enrollments e")) {
        result.valid = false; result.error = enroll.lastError().text(); return result;
    }
    QMap<int, QVector<int>> studentSubjects;
    QMap<int,int> subjectIndex;
    for (int i=0;i<n;++i) subjectIndex[ids[i]]=i;
    while (enroll.next()) {
        const int student = enroll.value(0).toInt();
        const int subject = enroll.value(1).toInt();
        if (subjectIndex.contains(subject)) studentSubjects[student].append(subjectIndex[subject]);
    }
    for (auto it=studentSubjects.cbegin(); it!=studentSubjects.cend(); ++it) {
        const auto list = it.value();
        for (int a=0;a<list.size();++a)
            for (int b=a+1;b<list.size();++b) {
                graph[list[a]].insert(list[b]);
                graph[list[b]].insert(list[a]);
            }
    }

    QVector<int> order;
    for (int i=0;i<n;++i) order << i;
    std::sort(order.begin(), order.end(), [&](int a,int b) {
        if (graph[a].size()!=graph[b].size()) return graph[a].size()>graph[b].size();
        return codes[a].compare(codes[b], Qt::CaseInsensitive)<0;
    });

    QVector<int> colors(n, -1);
    int color = 0;
    for (int pos=0; pos<n; ++pos) {
        const int v=order[pos];
        if (colors[v]!=-1) continue;
        colors[v]=color;
        for (int next=pos+1; next<n; ++next) {
            const int candidate=order[next];
            if (colors[candidate]!=-1) continue;
            bool canUse=true;
            for (int neighbor : graph[candidate])
                if (colors[neighbor]==color) { canUse=false; break; }
            if (canUse) colors[candidate]=color;
        }
        ++color;
    }
    result.slotCount=color;
    for (int i=0;i<n;++i) result.examSlots[codes[i]]=colors[i]+1;
    result.valid=validate(result.examSlots, &result.error);
    return result;
}

bool Scheduler::validate(const QMap<QString,int> &examSlots, QString *error) {
    QSqlQuery q(Database::connection());
    if (!q.exec(R"(
        SELECT s1.code, s2.code
        FROM enrollments e1
        JOIN enrollments e2 ON e1.student_id=e2.student_id AND e1.subject_id<e2.subject_id
        JOIN subjects s1 ON s1.id=e1.subject_id
        JOIN subjects s2 ON s2.id=e2.subject_id
    )")) {
        if (error) *error=q.lastError().text();
        return false;
    }
    while(q.next()) {
        const QString a=q.value(0).toString(), b=q.value(1).toString();
        if (examSlots.contains(a) && examSlots.contains(b) && examSlots[a]==examSlots[b]) {
            if (error) *error=QString("Conflict: %1 and %2 share a student in the same slot.").arg(a,b);
            return false;
        }
    }
    return true;
}
