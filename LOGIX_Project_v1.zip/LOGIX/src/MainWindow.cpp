#include "MainWindow.h"
#include "Database.h"
#include "Scheduler.h"
#include <QTabWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QHeaderView>
#include <QInputDialog>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlError>
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QTableWidgetItem>
#include <QGroupBox>
#include <QLabel>
#include <QLineEdit>
#include <QAbstractItemView>

MainWindow::MainWindow(QWidget *parent):QMainWindow(parent) {
    QString error;
    if (!Database::initialize(&error)) QMessageBox::critical(this,"LOGIX",error);
    setWindowTitle("LOGIX | Discrete Structures");
    resize(1180,760);
    auto *central=new QWidget;
    auto *root=new QVBoxLayout(central);
    auto *top=new QHBoxLayout;
    auto *brand=new QLabel("<span style='color:#E63946'>L</span>OGIX");
    brand->setObjectName("brand");
    auto *tag=new QLabel("THINK CLEAR. PROVE EVERYTHING.");
    tag->setObjectName("tagline");
    auto *lang=new QPushButton("العربية / EN");
    connect(lang,&QPushButton::clicked,this,&MainWindow::toggleLanguage);
    top->addWidget(brand); top->addSpacing(18); top->addWidget(tag); top->addStretch(); top->addWidget(lang);
    root->addLayout(top);
    tabs=new QTabWidget;
    auto *dashboard=new QWidget;
    auto *dashLayout=new QVBoxLayout(dashboard);
    auto *intro=new QLabel("EXAM SCHEDULING SYSTEM");
    intro->setObjectName("hero");
    dashLayout->addWidget(intro);
    auto *desc=new QLabel("Graph Coloring • Welsh-Powell Algorithm • Conflict-Free Timetables");
    desc->setObjectName("muted");
    dashLayout->addWidget(desc);
    auto *actions=new QHBoxLayout;
    auto *s1=new QPushButton("＋ Add Student"); connect(s1,&QPushButton::clicked,this,&MainWindow::addStudent);
    auto *s2=new QPushButton("＋ Add Subject"); connect(s2,&QPushButton::clicked,this,&MainWindow::addSubject);
    auto *s3=new QPushButton("＋ Enrollment"); connect(s3,&QPushButton::clicked,this,&MainWindow::addEnrollment);
    auto *s4=new QPushButton("Generate Schedule"); s4->setObjectName("primary"); connect(s4,&QPushButton::clicked,this,&MainWindow::generateSchedule);
    actions->addWidget(s1); actions->addWidget(s2); actions->addWidget(s3); actions->addWidget(s4);
    dashLayout->addLayout(actions);
    statusLabel=new QLabel("Ready. Add students, subjects and enrollments to begin.");
    statusLabel->setObjectName("status");
    dashLayout->addWidget(statusLabel);
    dashLayout->addStretch();
    tabs->addTab(dashboard,"Overview");
    tabs->addTab(makeDataPage(&studentsTable,{"ID","Student Code","Student Name"}),"Students");
    tabs->addTab(makeDataPage(&subjectsTable,{"ID","Subject Code","Subject Name"}),"Subjects");
    tabs->addTab(makeDataPage(&enrollTable,{"Student","Subject"}),"Enrollments");
    auto *schedulePage=new QWidget;
    auto *sl=new QVBoxLayout(schedulePage);
    scheduleTable=new QTableWidget(0,2);
    scheduleTable->setHorizontalHeaderLabels({"Exam Slot","Subject Code"});
    scheduleTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    auto *gen=new QPushButton("Generate with Welsh-Powell"); gen->setObjectName("primary");
    connect(gen,&QPushButton::clicked,this,&MainWindow::generateSchedule);
    auto *exp=new QPushButton("Export CSV"); connect(exp,&QPushButton::clicked,this,&MainWindow::exportSchedule);
    sl->addWidget(gen); sl->addWidget(scheduleTable); sl->addWidget(exp);
    tabs->addTab(schedulePage,"Exam Schedule");
    root->addWidget(tabs);
    setCentralWidget(central);
    setupStyle();
    refreshAll();
}

QWidget *MainWindow::makeDataPage(QTableWidget **table,const QStringList &headers) {
    auto *page=new QWidget; auto *layout=new QVBoxLayout(page);
    *table=new QTableWidget(0,headers.size());
    (*table)->setHorizontalHeaderLabels(headers);
    (*table)->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    (*table)->setEditTriggers(QAbstractItemView::NoEditTriggers);
    auto *bar=new QHBoxLayout;
    if (headers[0]=="ID") {
        const bool isStudents=headers[1]=="Student Code";
        auto *add=new QPushButton(isStudents?"Add Student":"Add Subject");
        connect(add,&QPushButton::clicked,this,isStudents?&MainWindow::addStudent:&MainWindow::addSubject);
        auto *imp=new QPushButton("Import CSV");
        connect(imp,&QPushButton::clicked,this,[this,isStudents]{importCsv(isStudents);});
        bar->addWidget(add); bar->addWidget(imp);
    } else {
        auto *add=new QPushButton("Add Enrollment"); connect(add,&QPushButton::clicked,this,&MainWindow::addEnrollment);
        bar->addWidget(add);
    }
    bar->addStretch();
    layout->addLayout(bar); layout->addWidget(*table);
    return page;
}

void MainWindow::refreshAll() {
    auto fill=[](QTableWidget *t,QSqlQuery &q,int cols) {
        t->setRowCount(0);
        while(q.next()) {
            int r=t->rowCount(); t->insertRow(r);
            for(int c=0;c<cols;++c) t->setItem(r,c,new QTableWidgetItem(q.value(c).toString()));
        }
    };
    QSqlQuery q(Database::connection());
    q.exec("SELECT id,code,name FROM students ORDER BY code"); fill(studentsTable,q,3);
    q.exec("SELECT id,code,name FROM subjects ORDER BY code"); fill(subjectsTable,q,3);
    q.exec("SELECT st.code, su.code FROM enrollments e JOIN students st ON st.id=e.student_id JOIN subjects su ON su.id=e.subject_id ORDER BY st.code,su.code"); fill(enrollTable,q,2);
    q.exec("SELECT es.slot,s.code FROM exam_schedule es JOIN subjects s ON s.id=es.subject_id ORDER BY es.slot,s.code"); fill(scheduleTable,q,2);
    statusLabel->setText(QString("Students: %1    Subjects: %2    Enrollments: %3")
        .arg(studentsTable->rowCount()).arg(subjectsTable->rowCount()).arg(enrollTable->rowCount()));
}

void MainWindow::addStudent() {
    bool ok=false; QString code=QInputDialog::getText(this,"Add Student","Student code:",QLineEdit::Normal,"",&ok).trimmed(); if(!ok||code.isEmpty()) return;
    QString name=QInputDialog::getText(this,"Add Student","Student name:",QLineEdit::Normal,"",&ok).trimmed(); if(!ok||name.isEmpty()) return;
    QSqlQuery q(Database::connection()); q.prepare("INSERT INTO students(code,name) VALUES(?,?)"); q.addBindValue(code); q.addBindValue(name);
    if(!q.exec()) QMessageBox::warning(this,"LOGIX",q.lastError().text()); refreshAll();
}
void MainWindow::addSubject() {
    bool ok=false; QString code=QInputDialog::getText(this,"Add Subject","Subject code:",QLineEdit::Normal,"",&ok).trimmed(); if(!ok||code.isEmpty()) return;
    QString name=QInputDialog::getText(this,"Add Subject","Subject name:",QLineEdit::Normal,"",&ok).trimmed(); if(!ok||name.isEmpty()) return;
    QSqlQuery q(Database::connection()); q.prepare("INSERT INTO subjects(code,name) VALUES(?,?)"); q.addBindValue(code); q.addBindValue(name);
    if(!q.exec()) QMessageBox::warning(this,"LOGIX",q.lastError().text()); refreshAll();
}
void MainWindow::addEnrollment() {
    QSqlQuery st(Database::connection()); st.exec("SELECT id,code FROM students ORDER BY code");
    QStringList students; QMap<QString,int> sm;
    while(st.next()){QString c=st.value(1).toString();students<<c;sm[c]=st.value(0).toInt();}
    QSqlQuery su(Database::connection()); su.exec("SELECT id,code FROM subjects ORDER BY code");
    QStringList subjects; QMap<QString,int> sum;
    while(su.next()){QString c=su.value(1).toString();subjects<<c;sum[c]=su.value(0).toInt();}
    if(students.isEmpty()||subjects.isEmpty()){QMessageBox::information(this,"LOGIX","Add at least one student and one subject first.");return;}
    bool ok=false; QString student=QInputDialog::getItem(this,"Enrollment","Student:",students,0,false,&ok); if(!ok)return;
    QString subject=QInputDialog::getItem(this,"Enrollment","Subject:",subjects,0,false,&ok); if(!ok)return;
    QSqlQuery q(Database::connection()); q.prepare("INSERT OR IGNORE INTO enrollments(student_id,subject_id) VALUES(?,?)");q.addBindValue(sm[student]);q.addBindValue(sum[subject]);
    if(!q.exec()) QMessageBox::warning(this,"LOGIX",q.lastError().text()); refreshAll();
}
void MainWindow::importCsv(bool students) {
    QString path=QFileDialog::getOpenFileName(this,"Import CSV",{}, "CSV files (*.csv)");
    if(path.isEmpty())return;
    QFile f(path); if(!f.open(QIODevice::ReadOnly|QIODevice::Text)){QMessageBox::warning(this,"LOGIX","Cannot open file.");return;}
    QTextStream in(&f); int count=0;
    while(!in.atEnd()) {
        QString line=in.readLine().trimmed(); if(line.isEmpty())continue;
        auto parts=line.split(','); if(parts.size()<2)continue;
        if(parts[0].trimmed().compare("code",Qt::CaseInsensitive)==0)continue;
        QSqlQuery q(Database::connection());
        if(students) q.prepare("INSERT OR IGNORE INTO students(code,name) VALUES(?,?)");
        else q.prepare("INSERT OR IGNORE INTO subjects(code,name) VALUES(?,?)");
        q.addBindValue(parts[0].trimmed()); q.addBindValue(parts.mid(1).join(",").trimmed());
        if(q.exec() && q.numRowsAffected()>0)++count;
    }
    QMessageBox::information(this,"LOGIX",QString("Imported %1 records.").arg(count)); refreshAll();
}
void MainWindow::generateSchedule() {
    auto result=Scheduler::build();
    if(!result.valid){QMessageBox::warning(this,"Scheduling",result.error);return;}
    QSqlQuery clear(Database::connection()); clear.exec("DELETE FROM exam_schedule");
    for(auto it=result.examSlots.cbegin();it!=result.examSlots.cend();++it){
        QSqlQuery q(Database::connection());q.prepare("INSERT INTO exam_schedule(subject_id,slot) SELECT id,? FROM subjects WHERE code=?");
        q.addBindValue(it.value());q.addBindValue(it.key());
        if(!q.exec()){QMessageBox::critical(this,"LOGIX",q.lastError().text());return;}
    }
    refreshAll();
    QMessageBox::information(this,"LOGIX",QString("Schedule generated successfully.\\nRequired exam examSlots: %1\\nConflict validation: PASSED").arg(result.slotCount));
}
void MainWindow::exportSchedule() {
    QString path=QFileDialog::getSaveFileName(this,"Export Schedule", "LOGIX_schedule.csv","CSV files (*.csv)");
    if(path.isEmpty())return;
    QFile f(path);if(!f.open(QIODevice::WriteOnly|QIODevice::Text)){QMessageBox::warning(this,"LOGIX","Cannot write file.");return;}
    QTextStream out(&f);out<<"Exam Slot,Subject Code,Subject Name\\n";
    QSqlQuery q(Database::connection());q.exec("SELECT es.slot,s.code,s.name FROM exam_schedule es JOIN subjects s ON s.id=es.subject_id ORDER BY es.slot,s.code");
    while(q.next())out<<q.value(0).toString()<<","<<q.value(1).toString()<<","<<q.value(2).toString()<<"\\n";
    QMessageBox::information(this,"LOGIX","CSV exported successfully.");
}
void MainWindow::toggleLanguage(){arabic=!arabic;applyLanguage();}
void MainWindow::applyLanguage(){
    setLayoutDirection(arabic?Qt::RightToLeft:Qt::LeftToRight);
    tabs->setTabText(0,arabic?"الرئيسية":"Overview");
    tabs->setTabText(1,arabic?"الطلاب":"Students");
    tabs->setTabText(2,arabic?"المواد":"Subjects");
    tabs->setTabText(3,arabic?"التسجيلات":"Enrollments");
    tabs->setTabText(4,arabic?"جدول الامتحانات":"Exam Schedule");
    setWindowTitle(arabic?"LOGIX | نظام تنظيم الامتحانات":"LOGIX | Discrete Structures");
}
void MainWindow::setupStyle(){
    setStyleSheet(R"(
      QWidget{background:#0B0B0F;color:#F5F5F5;font-family:'Montserrat','Segoe UI';}
      #brand{font-size:34px;font-weight:800;letter-spacing:3px;}
      #tagline,#muted{color:#9CA3AF;letter-spacing:2px;}
      #hero{font-size:28px;font-weight:700;margin-top:25px;}
      #status{background:#17171D;border:1px solid #34343B;border-radius:10px;padding:18px;font-size:15px;}
      QTabWidget::pane{border:1px solid #33333A;border-radius:8px;top:-1px;}
      QTabBar::tab{background:#17171D;padding:13px 22px;margin-right:3px;border-top-left-radius:6px;border-top-right-radius:6px;color:#B9B9C0;}
      QTabBar::tab:selected{background:#E63946;color:white;font-weight:700;}
      QPushButton{background:#24242C;border:1px solid #3B3B44;border-radius:7px;padding:11px 16px;color:#F5F5F5;}
      QPushButton:hover{border:1px solid #E63946;background:#303039;}
      QPushButton#primary{background:#E63946;border:0;font-weight:700;}
      QPushButton#primary:hover{background:#C92F3B;}
      QTableWidget{background:#111116;alternate-background-color:#19191F;gridline-color:#303039;border:1px solid #303039;border-radius:7px;}
      QHeaderView::section{background:#202027;color:#F5F5F5;padding:10px;border:0;border-bottom:2px solid #E63946;}
      QTableWidget::item{padding:7px;}
      QLineEdit,QComboBox{background:#17171D;border:1px solid #444;border-radius:5px;padding:7px;}
    )");
}
