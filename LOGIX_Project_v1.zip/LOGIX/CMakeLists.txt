cmake_minimum_required(VERSION 3.21)
project(LOGIX VERSION 1.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_AUTOMOC ON)
set(CMAKE_AUTOUIC ON)
set(CMAKE_AUTORCC ON)

find_package(Qt6 6.2 REQUIRED COMPONENTS Widgets Sql)

qt_add_executable(LOGIX
    src/main.cpp
    src/MainWindow.h
    src/MainWindow.cpp
    src/Scheduler.h
    src/Scheduler.cpp
    src/Database.h
    src/Database.cpp
)

target_link_libraries(LOGIX PRIVATE Qt6::Widgets Qt6::Sql)
