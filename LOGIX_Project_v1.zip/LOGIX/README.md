# LOGIX — Exam Scheduling System

A Qt 6 / C++17 Windows desktop starter application using Graph Coloring and the Welsh–Powell algorithm.

## Implemented in this starter
- SQLite local database (students, subjects, enrollments, generated schedule)
- Manual student and subject entry
- CSV import for students and subjects
- Manual enrollment creation
- Conflict graph construction from shared student enrollments
- Welsh–Powell coloring (descending vertex degree, greedy color assignment)
- Schedule validation against shared-student conflicts
- CSV schedule export
- Dark LOGIX red/black visual identity
- English/Arabic tab labels and layout-direction toggle

## Requirements
- Windows 10/11
- Visual Studio 2022 with **Desktop development with C++**
- Qt 6 (MSVC 2022 64-bit kit), including Qt Widgets and Qt SQL
- CMake 3.21+

## Build in Visual Studio 2022
1. Install Qt 6 for MSVC 2022 64-bit. Make sure the `Widgets` and `Sql` modules are installed.
2. Open Visual Studio 2022.
3. Select **File → Open → Folder** and choose this `LOGIX` folder (the folder containing `CMakeLists.txt`).
4. Select a CMake configuration that uses your Qt MSVC kit.
5. If CMake cannot find Qt, set `CMAKE_PREFIX_PATH` to your Qt MSVC installation, for example:
   `C:\Qt\6.x.x\msvc2022_64`
6. Build → Build All, then run the `LOGIX.exe` target.

Alternative command line:
```powershell
cmake -S . -B build -DCMAKE_PREFIX_PATH="C:/Qt/6.x.x/msvc2022_64"
cmake --build build --config Release
```

## CSV formats
Students:
```csv
code,name
ST001,Ahmed Ali
ST002,Mona Samir
```

Subjects:
```csv
code,name
CS101,Programming
MA101,Discrete Structures
```

CSV import currently expects simple comma-separated rows. For names containing commas or quoted fields, use a CSV-aware parser in a future iteration.

## Notes
- A schedule slot is a time period number, not a calendar date/time. Actual dates, rooms, durations, and invigilators can be added in a later version.
- Welsh–Powell is a heuristic coloring algorithm. It produces a valid conflict-free timetable when validation passes, but it does not guarantee the globally minimum number of slots for every graph.
- The application database is stored in the operating system's application data directory under `LOGIX/logix.db`.
